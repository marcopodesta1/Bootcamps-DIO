using DICOMViewer.Domain;
using DICOMViewer.Domain.Models;
using DICOMViewer.Infrastructure;
using DICOMViewer.Presentation;
using DICOMViewer.Presentation.View;
using System.Drawing;

namespace DICOMViewer.Presenter
{
    public class ImagePresenter
    {
        private readonly IMain _main;
        public ExamsCollection _examsCollections;
        private readonly List<Bitmap> _images = new();
        private CancellationTokenSource? _cts;
        private int _total = 0;

        public ImagePresenter(IMain view)
        {
            _main = view;
        }

        // public async Task LoadImagesAsync(string path, int resolution)
        // {
        //     _cts?.Cancel();
        //     _cts = new CancellationTokenSource();
        //     var token = _cts.Token;
        //     _images.Clear();
        //     _main.SetLoadingState(true);

        //     var reader = new DicomReader(path);
        //     await Task.Run(async () =>
        //     {
        //         await reader.LoadAsync(_main.ImageAreaSize, _images, resolution, token,
        //          (bmp, index, total) =>
        //          {
        //              _main.pbImage.Invoke(() =>
        //              {
        //                  if (index == 0)
        //                  {
        //                      _total = total;
        //                      _main.SetTrackbar(_total - 1);
        //                      _main.ShowImage(bmp);
        //                  }
        //                  _main.UpdateLoadCounter(index + 1, _total);
        //              });
        //          });
        //     }, token);


        //     _main.SetLoadingState(false);

        // }

        public async Task LoadImagesAsync(List<FileInfo> examsLIst, int resolution)
        {
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            _images.Clear();
            _main.SetLoadingState(true);

            var reader = new DicomReader();

            await Task.Run(async () =>
            {
                await reader.LoadAsync(examsLIst, _main.ImageAreaSize, _images, resolution, token,
                 (bmp, index, total) =>
                 {
                     _main.pbImage.Invoke(() =>
                     {
                         if (index == 0)
                         {
                             _total = total;
                             _main.SetTrackbar(_total - 1);
                             _main.ShowImage(bmp);
                         }
                         _main.UpdateLoadCounter(index + 1, _total);
                     });
                 });
            }, token);


            _main.SetLoadingState(false);

        }

        public async Task GetExamsSeparated(string path)
        {
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            _main.SetLoadingState(true);

            // try
            // {
            await Task.Run(async () =>
            {
                var reader = new DicomReader(path);
                _examsCollections = Task.Run(() => reader.SeparateExams(token, (index, total) =>
                {
                    _main.UpdateLoadCounter(index + 1, total);
                })).Result;
                //_main.DisplayExams(exams);

                var key = _examsCollections.Exams.Keys.ElementAt(5);
                LoadImagesAsync(_examsCollections.GetExamById(key), 72);
            });
            // }
            // catch { }
        }

        public void DisplayImage(int index)
        {
            try
            {
                if (index < 0 || index >= _total)
                    return;

                _main.ShowImage(_images[index]);
                _main.UpdateExamCounter(index + 1, _total);
                _main.SetTrackbarValue(index);
            }
            catch { }
        }

        public async Task SaveAsync(string path, int resolution)
        {
            if (_images.Count == 0) return;

            _cts ??= new CancellationTokenSource();
            var token = _cts.Token;

            _main.SetSavingState(true);

            var saver = new ImageSaver();

            await saver.SaveAsync(
                _images,
                path,
                resolution,
                progress => _main.UpdateSaveProgress(progress, _images.Count),
                token);

            _main.SetSavingState(false);
        }

        public void Cancel()
        {
            _cts?.Cancel();
        }
    }
}
