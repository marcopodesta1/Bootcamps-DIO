using FellowOakDicom;

namespace DICOMViewer.Domain.Models;

public class ExamsCollection
{
    public Dictionary<string, List<ExamsInfo>> Exams { get; set; } = new();
    public int InstanceNumberTag { get; set; }

    public List<FileInfo> GetExamById(string examId)
     => Exams.TryGetValue(examId, out var files) ? files.Select(x => x.File).ToList() 
                                                 : new List<FileInfo>();
}



public class ExamsInfo
{
    public FileInfo File { get; set; }
    public int InstanceNumber { get; set; }
}