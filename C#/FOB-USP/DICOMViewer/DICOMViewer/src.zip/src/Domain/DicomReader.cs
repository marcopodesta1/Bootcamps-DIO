using DICOMViewer.Domain.Models;
using FellowOakDicom;
using FellowOakDicom.Imaging;
using System.Drawing;

namespace DICOMViewer.Domain
{
    public class DicomReader
    {
        private readonly string _path;

        public DicomReader() { }

        public DicomReader(string path)
        {
            _path = path;
        }

        public async Task LoadAsync(List<FileInfo> files,
                                    Size targetSize,
                                    List<Bitmap> images,
                                    int resolution,
                                    CancellationToken token,
                                    Action<Bitmap, int, int>? onImageLoaded = null)
        {
            // var files = new DirectoryInfo(_path).GetFiles()
            //                                     .OrderBy(f => f.FullName)
            //                                     .ToArray();
            if (files.Count == 0)
                return;

            int total = files.Count;

            for (int index = 0; index < total; index++)
            {
                token.ThrowIfCancellationRequested();

                var dicomFile = await DicomFile.OpenAsync(files[index].FullName);
                var dataset = dicomFile.Dataset;
                dataset.AutoValidate = false;

                var dicomImage = new DicomImage(dataset);
                using var rendered = dicomImage.RenderImage().AsSharedBitmap();
                var bmp = new Bitmap(rendered, targetSize.Width, targetSize.Height);
                bmp.SetResolution(resolution, resolution);

                lock (images)
                    images.Add(bmp);

                onImageLoaded?.Invoke(bmp, index, total);
            }
        }

        public async Task<ExamsCollection> SeparateExams(CancellationToken token,
                                                         Action<int, int>? onExamsSeparated = null)
        {
            var examDict = new ExamsCollection();

            var files = new DirectoryInfo(_path)
                .GetFiles("*.*")
                .OrderBy(f => f.FullName)
                .ToArray();

            int total = files.Length;

            for (int index = 0; index < files.Length; index++)
            {
                token.ThrowIfCancellationRequested();

                var file = files[index];

                // Abre o arquivo DICOM
                var dicomFile = DicomFile.Open(file.FullName);
                var dataset = dicomFile.Dataset;
                dataset.AutoValidate = false;

                string examName = dataset.GetSingleValueOrDefault(DicomTag.SeriesDescription, "Unknown Exam");

                int instanceNumber = dataset.GetSingleValueOrDefault<int>(DicomTag.InstanceNumber, 0);

                if (!examDict.Exams.ContainsKey(examName))
                    examDict.Exams[examName] = new List<ExamsInfo>();

                examDict.Exams[examName].Add(new ExamsInfo
                {
                    File = file,
                    InstanceNumber = instanceNumber
                });

                onExamsSeparated?.Invoke(index + 1, total);
            }

            foreach (var examId in examDict.Exams.Keys.ToList())
            {
                examDict.Exams[examId] = examDict.Exams[examId]
                    .OrderBy(x => x.InstanceNumber)
                    .ToList();
            }

            return examDict;
        }

    }
}
