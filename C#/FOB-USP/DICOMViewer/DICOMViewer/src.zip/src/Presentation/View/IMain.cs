using System.Drawing;

namespace DICOMViewer.Presentation.View
{
    public interface IMain
    {
        PictureBox pbImage { get; }
        void ShowImage(Bitmap bmp);

        void UpdateLoadCounter(int index, int total);
        void UpdateExamCounter(int index, int total);

        void UpdateSaveProgress(int value, int max);

        void SetTrackbar(int max);
        void SetTrackbarValue(int index);

        void SetLoadingState(bool isLoading);
        void SetSavingState(bool isSaving);

        Size ImageAreaSize { get; }
        
    }
}
