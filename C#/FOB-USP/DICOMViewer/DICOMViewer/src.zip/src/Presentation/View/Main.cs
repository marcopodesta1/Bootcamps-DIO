using DICOMViewer.Presenter;

namespace DICOMViewer.Presentation.View
{
    public partial class Main : Form, IMain
    {
        private readonly ImagePresenter _presenter;
        PictureBox IMain.pbImage => pbImage;

        public Main()
        {
            InitializeComponent();

            _presenter = new ImagePresenter(this);
            pbImage.MouseWheel += PbImage_MouseWheel;
        }

        public Size ImageAreaSize => pbImage.Size;

        

        public void ShowImage(Bitmap bmp)
        {
            UI(() => pbImage.Image = bmp);
        }

        public void UpdateLoadCounter(int index, int total)
        {
            UI(() =>
            {
                lblCount.Visible = true;
                lblCount.Text = $"{index} / {total}";
            });
        }

        public void UpdateExamCounter(int index, int total)
        {
            UI(() =>
            {
                lblExam.Visible = true;
                lblExam.Text = $"{index} / {total}";
            });

        }

        public void UpdateSaveProgress(int value, int max)
        {
            UI(() =>
            {
                pbProgress.Visible = value < max;
                pbProgress.Maximum = Math.Max(1, max);
                pbProgress.Value = Math.Min(value, pbProgress.Maximum);
            });
        }


        public void SetTrackbar(int max)
        {
            UI(() =>
            {
                trackBar.Visible = true;
                trackBar.Minimum = 0;
                trackBar.Maximum = Math.Max(0, max);
            });
        }


        public void SetTrackbarValue(int index)
        {
            trackBar.Value = index;
        }

        public void SetLoadingState(bool isLoading)
        {
            UI(() =>
            {
                btnOpen.Enabled = !isLoading;
                btnCancel.Enabled = isLoading;
                txtResolution.Enabled = !isLoading;
            });
        }


        public void SetSavingState(bool isSaving)
        {
            UI(() =>
            {
                btnSave.Enabled = !isSaving;
                btnCancel.Enabled = isSaving;
            });
        }


        private async void btnOpen_Click(object sender, EventArgs e)
        {
            using var dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                int resolution = Convert.ToInt32(txtResolution.Text);
                //await _presenter.LoadImagesAsync(dialog.SelectedPath, resolution);
                await _presenter.GetExamsSeparated(dialog.SelectedPath);
            }
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            using var dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                int resolution = Convert.ToInt32(txtResolution.Text);
                await _presenter.SaveAsync(dialog.SelectedPath, resolution);
            }
        }

        private void trackBar_ValueChanged(object sender, EventArgs e)
        {
            _presenter.DisplayImage(trackBar.Value);
        }

        private void PbImage_MouseWheel(object sender, MouseEventArgs e)
        {
            if (e.Delta > 0 && trackBar.Value < trackBar.Maximum)
                trackBar.Value++;
            else if (e.Delta < 0 && trackBar.Value > trackBar.Minimum)
                trackBar.Value--;
        }

        private void txtResolution_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite apenas n�meros e teclas de controle (Backspace, Delete, etc.)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            _presenter.Cancel();
        }

        private void UI(Action action)
        {
            if (InvokeRequired)
                Invoke(action);
            else
                action();
        }
    }
}
