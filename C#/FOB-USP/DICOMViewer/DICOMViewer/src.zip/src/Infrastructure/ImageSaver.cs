using System.Drawing;
using System.Drawing.Imaging;

namespace DICOMViewer.Infrastructure
{
    public class ImageSaver
    {
        public Task SaveAsync(
            List<Bitmap> images,
            string path,
            int resolution,
            Action<int>? progress,
            CancellationToken token)
        {
            return Task.Run(() =>
            {
                for (int i = 0; i < images.Count; i++)
                {
                    token.ThrowIfCancellationRequested();

                    string filePath = Path.Combine(path, $"Corte_{i + 1:D4}.tif");

                    images[i].SetResolution(resolution, resolution);
                    images[i].Save(filePath, ImageFormat.Tiff);

                    progress?.Invoke(i + 1);
                }
            }, token);
        }
    }
}
