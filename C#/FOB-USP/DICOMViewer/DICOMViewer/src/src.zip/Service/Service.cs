using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DICOMViewer
{
    public class Service
    {
        private readonly PictureBox PbImage;
        private readonly TrackBar TrackBar;
        private readonly Label LblCount;
        private readonly Label LblExam;
        private readonly Button BtnSave;
        private readonly Button BtnCancel;
        private readonly TextBox TxtResolution;
        private readonly ProgressBar PbProgress;
        private CancellationTokenSource? _cts;
        private readonly List<Bitmap> images = new();
        private int Resolution;
        private int TotalOfExams;

        public Service(PictureBox pbImage, TrackBar trackBar, Label lblCount, Label lblExam, Button btnSave, Button btnCancel, ProgressBar pbProgress, TextBox txtResolution)
        {
            PbImage = pbImage;
            TrackBar = trackBar;
            LblCount = lblCount;
            BtnSave = btnSave;
            BtnCancel = btnCancel;
            PbProgress = pbProgress;
            TxtResolution = txtResolution;
            LblExam = lblExam;
        }

        public async Task GetImagesAsync(string path, int resolution)
        {
            _cts?.Cancel();
            _cts = new CancellationTokenSource();
            var token = _cts.Token;
            images.Clear();

            var dicom = new Dicom(path, PbImage.Size, LblCount);
            BtnCancel.Enabled = true;
            TxtResolution.Enabled = false;
            // BtnCancel.Update();
            await Task.Run(async () =>
            {
                await dicom.OpenAsync(token, images, resolution,
                    (bmp, index, total) =>
                    {
                        // Atualiza interface sem travar
                        PbImage.Invoke(() =>
                        {
                            TotalOfExams = total;
                            // Mostra primeira imagem imediatamente
                            if (index == 0)
                            {
                                LblCount.Visible = true;
                                LblCount.Update();
                                TrackBar.Visible = true;
                                TrackBar.Update();
                                DisplayImage(0);
                                ConfigureTrackBar(total);
                            }

                            // Atualiza contador simples
                            LblCount.Text = $"{index + 1} / {total}";
                            LblCount.Update();
                        });
                    });
            }, token);
            BtnSave.Enabled = true;
            LblCount.ResetText();
            LblCount.Visible = false;

        }

        public void CancelLoad()
        {
            _cts?.Cancel();
            BtnSave.Enabled = false;
            BtnCancel.Enabled = false;
            TxtResolution.Enabled = true;
            PbImage.Image = null;
            TrackBar.Visible = false;
            LblCount.Text = String.Empty;
            LblCount.Visible = false;

            images.Clear();
        }

        private void ConfigureTrackBar(int total)
        {
            TrackBar.Visible = true;
            TrackBar.Minimum = 0;
            TrackBar.Maximum = Math.Max(0, total - 1);
            TrackBar.Value = 0;
        }

        public void DisplayImage(int index)
        {
            if (index >= 0 && index < images.Count)
            {
                if(index == 0) LblExam.Visible = true;
                PbImage.Image = images[index];
                LblExam.Text = @$"{index + 1} / {TotalOfExams}";
            }
        }

        public async void Save(string path, int resolution)
        {
            ConfigProgressBar(images.Count);
            var token = _cts.Token;
            await Task.Run(async () =>
            {
                BtnCancel.Enabled = true;
                for (int i = 0; i < images.Count; i++)
                {
                    string filePath = System.IO.Path.Combine(path, $"Corte_{i + 1:D4}.tif");
                    images[i].SetResolution(resolution, resolution);
                    images[i].Save(filePath, System.Drawing.Imaging.ImageFormat.Tiff);
                    PbProgress.Value = i + 1;
                }
                PbProgress.Visible = false;
            }, token);


        }
        private void ConfigProgressBar(int total)
        {
            PbProgress.Minimum = 0;
            PbProgress.Maximum = total;
            PbProgress.Value = 0;
            PbProgress.Step = 1;
            PbProgress.Visible = true;
        }
    }
}
