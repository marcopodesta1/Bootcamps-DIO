using FellowOakDicom;
using FellowOakDicom.Imaging;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace DICOMViewer
{
    public class Dicom
    {
        private readonly string Path;
        private readonly Size SizeOfPbImage;
        private readonly Label LblCount;

        public Dicom(string path, Size sizeOfPbImage, Label lblCount)
        {
            Path = path;
            SizeOfPbImage = sizeOfPbImage;
            LblCount = lblCount;
        }

        public async Task OpenAsync(
            CancellationToken token,
            List<Bitmap> images,
            int resolution,
            Action<Bitmap, int, int>? onImageLoaded = null)
        {
            var files = new DirectoryInfo(Path)
                .GetFiles("*.*")
                .OrderBy(f => f.FullName)
                .ToArray();

            if (files.Length == 0)
                return;


            int total = files.Length;

            for (int index = 0; index < total; index++)
            {
                token.ThrowIfCancellationRequested();

                var dicomFile = await DicomFile.OpenAsync(files[index].FullName);
                var dataset = dicomFile.Dataset;
                dataset.AutoValidate = false;

                var dicomImage = new DicomImage(dataset);
                using var rendered = dicomImage.RenderImage().As<Bitmap>();  //AsSharedBitmap();
                var bmp = new Bitmap(rendered, SizeOfPbImage.Width, SizeOfPbImage.Height);
                bmp.SetResolution(resolution, resolution);

                lock (images)
                    images.Add(bmp);

                onImageLoaded?.Invoke(bmp, index, total);
            }
        }
    }
}

