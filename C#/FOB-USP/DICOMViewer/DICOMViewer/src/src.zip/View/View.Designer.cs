﻿namespace DICOMViewer
{
    partial class View
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pbImage = new PictureBox();
            pnlDicom = new Panel();
            pbProgress = new ProgressBar();
            trackBar = new TrackBar();
            pnlButtons = new Panel();
            btnCancel = new Button();
            lblResolution = new Label();
            txtResolution = new TextBox();
            lblCount = new Label();
            btnSave = new Button();
            btnOpen = new Button();
            lblExam = new Label();
            ((System.ComponentModel.ISupportInitialize)pbImage).BeginInit();
            pnlDicom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)trackBar).BeginInit();
            pnlButtons.SuspendLayout();
            SuspendLayout();
            // 
            // pbImage
            // 
            pbImage.Anchor = AnchorStyles.None;
            pbImage.BackColor = Color.Black;
            pbImage.BackgroundImageLayout = ImageLayout.Stretch;
            pbImage.Location = new Point(0, 0);
            pbImage.Name = "pbImage";
            pbImage.Size = new Size(790, 790);
            pbImage.TabIndex = 0;
            pbImage.TabStop = false;
            // 
            // pnlDicom
            // 
            pnlDicom.Anchor = AnchorStyles.None;
            pnlDicom.BackColor = Color.Black;
            pnlDicom.Controls.Add(lblExam);
            pnlDicom.Controls.Add(pbProgress);
            pnlDicom.Controls.Add(trackBar);
            pnlDicom.Controls.Add(pbImage);
            pnlDicom.Location = new Point(1, 39);
            pnlDicom.Name = "pnlDicom";
            pnlDicom.Size = new Size(837, 790);
            pnlDicom.TabIndex = 1;
            // 
            // pbProgress
            // 
            pbProgress.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            pbProgress.Location = new Point(134, 400);
            pbProgress.Name = "pbProgress";
            pbProgress.Size = new Size(566, 23);
            pbProgress.TabIndex = 3;
            pbProgress.Visible = false;
            // 
            // trackBar
            // 
            trackBar.Anchor = AnchorStyles.None;
            trackBar.BackColor = Color.Black;
            trackBar.Location = new Point(789, 0);
            trackBar.Name = "trackBar";
            trackBar.Orientation = Orientation.Vertical;
            trackBar.Size = new Size(45, 790);
            trackBar.TabIndex = 2;
            trackBar.Visible = false;
            trackBar.ValueChanged += trackBar_ValueChanged;
            // 
            // pnlButtons
            // 
            pnlButtons.Anchor = AnchorStyles.None;
            pnlButtons.Controls.Add(btnCancel);
            pnlButtons.Controls.Add(lblResolution);
            pnlButtons.Controls.Add(txtResolution);
            pnlButtons.Controls.Add(lblCount);
            pnlButtons.Controls.Add(btnSave);
            pnlButtons.Controls.Add(btnOpen);
            pnlButtons.Location = new Point(2, 2);
            pnlButtons.Name = "pnlButtons";
            pnlButtons.Size = new Size(837, 35);
            pnlButtons.TabIndex = 2;
            // 
            // btnCancel
            // 
            btnCancel.Anchor = AnchorStyles.None;
            btnCancel.Enabled = false;
            btnCancel.Location = new Point(566, 4);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(133, 27);
            btnCancel.TabIndex = 5;
            btnCancel.Text = "Cancelar";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // lblResolution
            // 
            lblResolution.AutoSize = true;
            lblResolution.Location = new Point(6, 10);
            lblResolution.Name = "lblResolution";
            lblResolution.Size = new Size(64, 15);
            lblResolution.TabIndex = 4;
            lblResolution.Text = "Resolução:";
            // 
            // txtResolution
            // 
            txtResolution.Location = new Point(71, 6);
            txtResolution.MaxLength = 3;
            txtResolution.Name = "txtResolution";
            txtResolution.Size = new Size(40, 23);
            txtResolution.TabIndex = 3;
            txtResolution.Text = "300";
            txtResolution.TextAlign = HorizontalAlignment.Center;
            txtResolution.KeyPress += txtResolution_KeyPress;
            // 
            // lblCount
            // 
            lblCount.Anchor = AnchorStyles.None;
            lblCount.Location = new Point(758, 10);
            lblCount.Name = "lblCount";
            lblCount.Size = new Size(66, 15);
            lblCount.TabIndex = 2;
            lblCount.Text = "0 / 0";
            lblCount.TextAlign = ContentAlignment.MiddleRight;
            lblCount.Visible = false;
            // 
            // btnSave
            // 
            btnSave.Anchor = AnchorStyles.None;
            btnSave.Enabled = false;
            btnSave.Location = new Point(366, 4);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(133, 27);
            btnSave.TabIndex = 1;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnOpen
            // 
            btnOpen.Anchor = AnchorStyles.None;
            btnOpen.Location = new Point(166, 4);
            btnOpen.Name = "btnOpen";
            btnOpen.Size = new Size(133, 27);
            btnOpen.TabIndex = 0;
            btnOpen.Text = "Abrir";
            btnOpen.UseVisualStyleBackColor = true;
            btnOpen.Click += btnOpen_Click;
            // 
            // lblExam
            // 
            lblExam.Anchor = AnchorStyles.None;
            lblExam.ForeColor = Color.White;
            lblExam.Location = new Point(712, 16);
            lblExam.Name = "lblExam";
            lblExam.Size = new Size(66, 15);
            lblExam.TabIndex = 6;
            lblExam.Text = "0 / 0";
            lblExam.TextAlign = ContentAlignment.MiddleRight;
            lblExam.Visible = false;
            // 
            // View
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSteelBlue;
            ClientSize = new Size(838, 827);
            Controls.Add(pnlButtons);
            Controls.Add(pnlDicom);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Name = "View";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pbImage).EndInit();
            pnlDicom.ResumeLayout(false);
            pnlDicom.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)trackBar).EndInit();
            pnlButtons.ResumeLayout(false);
            pnlButtons.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pbImage;
        private Panel pnlDicom;
        private TrackBar trackBar;
        private Panel pnlButtons;
        private Button btnSave;
        private Button btnOpen;
        private Label lblCount;
        private TextBox txtResolution;
        private Label lblResolution;
        private Button btnCancel;
        private ProgressBar pbProgress;
        private Label lblExam;
    }
}
