using Microsoft.Win32;

namespace DICOMViewer
{
    public partial class View : Form
    {
        Service service;
        int Resolution;
        public View()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
            Resolution = Convert.ToInt32(txtResolution.Text);
            service = new Service(pbImage, trackBar, lblCount, lblExam, btnSave, btnCancel, pbProgress, txtResolution);
            pbImage.MouseWheel += new MouseEventHandler(PbImage_MouseWheel);
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            if(dialog.ShowDialog() == DialogResult.OK)
            {
                string path = dialog.SelectedPath;
                service.GetImagesAsync(path, Resolution);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            if(dialog.ShowDialog() == DialogResult.OK)
            {
                txtResolution.Enabled = false;
                string path = dialog.SelectedPath;
                service.Save(path, Resolution);
            }
        }

        private void trackBar_ValueChanged(object sender, EventArgs e)
        {
            service.DisplayImage(trackBar.Value);
            //lblCount.Text = trackBar.Value.ToString();
        }

        internal void PbImage_MouseWheel(object? sender, MouseEventArgs e)
        {
            if(e.Delta > 0 && trackBar.Value < trackBar.Maximum)
                trackBar.Value += 1;
            else if(e.Delta < 0 && trackBar.Value > trackBar.Minimum)
                trackBar.Value -= 1;
        }

        private void txtResolution_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite apenas n�meros e teclas de controle (Backspace, Delete, etc.)
            if(!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            service.CancelLoad();
            
        }
    }
}
